﻿namespace BakeryOpenning
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {

            Employee Mitko = new Employee("Mitko", 25, "Bulgaria");
            Console.WriteLine(Mitko);
        }
    }
}
